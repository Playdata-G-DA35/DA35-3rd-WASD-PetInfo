import nltk
from nltk.corpus import stopwords
from nltk.stem import  PorterStemmer, LancasterStemmer, SnowballStemmer
import pandas as pd
import matplotlib.pyplot as plt
from nltk import Text, FreqDist
import numpy as np



